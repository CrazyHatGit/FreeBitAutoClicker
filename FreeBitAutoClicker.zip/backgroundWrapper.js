try {
  importScripts("/source/background.js")
} catch (e) {
  console.error(e);
}